from sys import argv
from Crypto.Cipher import AES
keyfile = argv[1]

flag = ()

print "usage: python keygen.py keyfile seek len"

with open(keyfile, "r") as kf:
    i = int(argv[2])
    l = int(argv[3])
    aes = AES.new(
        kf.read()[i:i+l], AES.MODE_CBC,
        'dng3rousb1zFr0do')

    flag = aes.decrypt(flag)
    length = ord(flag[-1])
    flag = flag[0:len(flag) - length]
    print flag
